// File path: src/main/main.js
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs/promises');
const os = require('os'); 
const ffmpeg = require('fluent-ffmpeg'); 
const { exec } = require('child_process');
const crypto = require('crypto');

const { 
    createProjectStructure, getProjectList, copySourcesToProject, getProjectSources, 
    saveMetadata, getMetadata, deleteProject, getScriptHistory, saveScriptHistory,
    listScripts, saveScriptRecord, deleteScriptRecord, getProjectConfig, saveProjectConfig,
    getFinalVideos, saveLearnedStyle, getLearnedStyles, getApiLogs, saveApiLog
} = require('../utils/file_system');

const { analyzeVideoSource } = require('../services/openai_vision');
const { extractAudioAndSTT } = require('../local_core/whisper_stt');
const { generateNewScripts, analyzeScriptStructure } = require('../services/openai_text');
const { generateVoiceFile, getVoices } = require('../services/larvoice');
const { generateEverAIVoice } = require('../services/everai');
const { buildTimeline } = require('../local_core/metadata_matcher');
const { renderFinalVideo } = require('../local_core/ffmpeg_render');

let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1280, height: 800, title: "AI Video Factory - Ultra Pro",
        webPreferences: { 
            nodeIntegration: false, 
            contextIsolation: true, 
            webSecurity: false, 
            preload: path.join(__dirname, 'preload.js') 
        }
    });
    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
}

app.whenReady().then(() => {
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

const WORKSPACE_PATH = path.join(app.getPath('documents'), 'AIVideoFactory_Workspace');

global.isProcessStopped = false;

function sendLog(msg, type = 'info') {
    if (mainWindow && mainWindow.webContents) mainWindow.webContents.send('backend-log', { msg, type });
    console.log(`[${type.toUpperCase()}] ${msg}`);
}

function sendProgress(taskName, percent) {
    if (mainWindow && mainWindow.webContents) mainWindow.webContents.send('backend-progress', { task: taskName, percent: percent });
}

async function logApiUsage(projectName, service, task, usage, tokens = 0) {
    let costVND = 0;
    if (service === 'kie') costVND = usage * 126;
    else if (service === 'ever') costVND = usage * 0.495;
    else if (service === 'lar') costVND = usage * 0.5;

    const logEntry = {
        id: crypto.randomBytes(4).toString('hex'),
        timestamp: new Date().toISOString(),
        dateStr: new Date().toLocaleDateString('vi-VN'),
        projectName: projectName || 'Hệ thống',
        service: service,
        task: task,
        usage: usage,
        tokens: tokens,
        costVND: Math.round(costVND)
    };

    await saveApiLog(WORKSPACE_PATH, logEntry);
    if (mainWindow && mainWindow.webContents) {
        mainWindow.webContents.send('api-usage', logEntry);
    }
    return Math.round(costVND);
}

ipcMain.handle('api:getLogs', async () => { return await getApiLogs(WORKSPACE_PATH); });
ipcMain.handle('process:stop', () => { global.isProcessStopped = true; sendLog('Hệ thống đã nhận lệnh DỪNG từ người dùng!', 'warning'); return true; });
ipcMain.handle('process:reset', () => { global.isProcessStopped = false; return true; });

ipcMain.handle('system:getFonts', async () => {
    return new Promise((resolve) => {
        const fallbackFonts = ['Arial', 'Times New Roman', 'Tahoma', 'Verdana', 'Helvetica', 'Montserrat', 'Open Sans', 'Roboto', 'SVN-Gotham', 'UTM Avo', 'UTM Bebas', 'Impact', 'Comic Sans MS'];
        if (process.platform !== 'win32') return resolve(fallbackFonts);
        exec('chcp 65001 >nul && powershell -Command "[System.Drawing.Text.InstalledFontCollection]::new().Families.Name"', (err, stdout) => {
            if (err) return resolve(fallbackFonts);
            const fonts = stdout.split('\n').map(f => f.trim()).filter(f => f);
            if(fonts.length < 5) return resolve(fallbackFonts);
            resolve(fonts);
        });
    });
});

ipcMain.handle('project:list', async () => { try { return await getProjectList(WORKSPACE_PATH); } catch (e) { return []; } });
ipcMain.handle('project:create', async (e, n) => { try { return { success: true, path: await createProjectStructure(n, WORKSPACE_PATH), name: n }; } catch (err) { return { success: false, error: err.message }; } });
ipcMain.handle('project:delete', async (e, n) => { if(!n) return {success: false}; try { await deleteProject(WORKSPACE_PATH, n); return { success: true }; } catch (err) { return { success: false, error: err.message }; } });
ipcMain.handle('project:getConfig', async (e, n) => { if (!n) return null; try { return await getProjectConfig(path.join(WORKSPACE_PATH, n)); } catch (err) { return null; } });
ipcMain.handle('project:saveConfig', async (e, n, d) => { if (!n) return {success: false}; try { await saveProjectConfig(path.join(WORKSPACE_PATH, n), d); return { success: true }; } catch (err) { return { success: false, error: err.message }; } });

ipcMain.handle('dialog:openFiles', async () => {
    const res = await dialog.showOpenDialog(mainWindow, { properties: ['openFile', 'multiSelections'], filters: [{ name: 'Videos', extensions: ['mp4', 'mov'] }] });
    return res.canceled ? [] : res.filePaths;
});
ipcMain.handle('dialog:openAudioFile', async () => {
    const res = await dialog.showOpenDialog(mainWindow, { title: 'Chọn âm thanh chuyển cảnh', properties: ['openFile'], filters: [{ name: 'Audio', extensions: ['wav', 'mp3', 'm4a', 'aac'] }] });
    return res.canceled ? null : res.filePaths[0];
});
ipcMain.handle('dialog:openDirectory', async () => {
    const res = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
    return res.canceled ? null : res.filePaths[0];
});
ipcMain.handle('os:openFolder', async (e, f) => { try { shell.showItemInFolder(f); } catch (err) {} });
ipcMain.handle('os:openPath', async (e, p) => { try { shell.openPath(p); } catch (err) {} });
ipcMain.handle('os:openDefaultOutputDir', async (e, n) => {
    try { shell.openPath(path.join(WORKSPACE_PATH, n, '07_Product')); } catch (err) {}
});

ipcMain.handle('source:upload', async (e, n, p) => { 
    if (!n) return { success: false, error: "Tên dự án rỗng" };
    try { 
        await copySourcesToProject(path.join(WORKSPACE_PATH, n), p); 
        sendLog(`Đã upload ${p.length} file vào dự án.`); 
        return { success: true }; 
    } catch (err) { return { success: false, error: err.message }; } 
});

ipcMain.handle('source:list', async (e, n) => { 
    if (!n) return []; 
    try { return await getProjectSources(path.join(WORKSPACE_PATH, n)); } catch (err) { return []; } 
});

ipcMain.handle('ai:analyze', async (e, n, f, k, fps) => {
    if (!n) return { success: false, error: "Chưa chọn dự án" };
    try {
        sendLog(`Đang quét AI cho file: ${f}...`);
        const p = path.join(WORKSPACE_PATH, n);
        const config = await getProjectConfig(p) || {};
        const targetFps = parseInt(fps) || 15;
        
        const cleanK = typeof k === 'string' ? k : k?.apiKey;
        const resObj = await analyzeVideoSource(path.join(p, '01_Source', f), cleanK, { name: config.productName||"", desc: config.productDesc||"", price: config.productPrice||"" }, targetFps);
        await saveMetadata(p, f, resObj.meta);
        
        await logApiUsage(n, 'kie', `Quét Video (${f})`, resObj.credits, resObj.tokens);
        
        sendLog(`Quét AI thành công: ${f}`, 'success');
        return { success: true };
    } catch (err) { 
        sendLog(`Lỗi quét AI file ${f}: ${err.message}`, 'error');
        return { success: false, error: err.message }; 
    }
});

ipcMain.handle('metadata:get', async (e, n, f) => { if (!n) return null; try { return await getMetadata(path.join(WORKSPACE_PATH, n), f); } catch (err) { return null; } });
ipcMain.handle('metadata:save', async (e, n, f, d) => { if (!n) return {success: false}; try { await saveMetadata(path.join(WORKSPACE_PATH, n), f, d); return { success: true }; } catch (err) { return { success: false, error: err.message }; } });

ipcMain.handle('video:downloadAndAnalyze', async (e, n, url, k, fps) => {
    if (!n) return { success: false };
    return new Promise((resolve) => {
        sendLog(`Đang gọi yt-dlp tải video từ: ${url}`);
        const sourceDir = path.join(WORKSPACE_PATH, n, '01_Source');
        const randomId = 'DL_' + Date.now();
        const outputTemplate = path.join(sourceDir, `${randomId}.mp4`);
        
        exec(`yt-dlp -f "bestvideo+bestaudio/best" -o "${outputTemplate}" "${url}"`, async (err, stdout, stderr) => {
            if (err) {
                sendLog(`Lỗi tải video: ${err.message}`, 'error');
                return resolve({ success: false, error: err.message });
            }
            sendLog(`Tải video thành công, đang đẩy qua AI quét...`);
            try {
                const config = await getProjectConfig(path.join(WORKSPACE_PATH, n)) || {};
                const targetFps = parseInt(fps) || 15;
                const cleanK = typeof k === 'string' ? k : k?.apiKey;
                
                const resObj = await analyzeVideoSource(outputTemplate, cleanK, { name: config.productName||"", desc: config.productDesc||"", price: config.productPrice||"" }, targetFps);
                await saveMetadata(path.join(WORKSPACE_PATH, n), `${randomId}.mp4`, resObj.meta);
                
                await logApiUsage(n, 'kie', 'Quét Video Download', resObj.credits, resObj.tokens);

                sendLog(`Quét video tải về thành công!`, 'success');
                resolve({ success: true });
            } catch(aiErr) {
                sendLog(`Lỗi AI: ${aiErr.message}`, 'error');
                resolve({ success: false, error: aiErr.message });
            }
        });
    });
});

ipcMain.handle('ai:learnScriptStyle', async (e, projectName, link, apiKey) => {
    const cleanK = typeof apiKey === 'string' ? apiKey : apiKey?.apiKey;
    if(!projectName || !cleanK) return {success: false, error: "Thiếu dữ kiện API Key."};
    sendLog(`[HỌC KỊCH BẢN] Bắt đầu tải Audio từ: ${link}`);
    
    const projPath = path.join(WORKSPACE_PATH, projectName);
    const tempMp3 = path.join(os.tmpdir(), `learn_${Date.now()}.mp3`);
    
    return new Promise((resolve) => {
        exec(`yt-dlp -f "bestaudio/best" --extract-audio --audio-format mp3 -o "${tempMp3}" "${link}"`, async (err) => {
            if(err) {
                sendLog(`[LỖI TẢI AUDIO] ${err.message}`, 'error');
                return resolve({success:false, error: err.message});
            }
            
            try {
                sendLog(`Đã tải Audio. Đang bóc băng bằng Whisper...`);
                const transcript = await extractAudioAndSTT(tempMp3, cleanK);
                sendLog(`Đã bóc băng thành chữ. Đang phân tích cấu trúc bằng Kie.ai...`);
                
                const resObj = await analyzeScriptStructure(cleanK, transcript);
                await logApiUsage(projectName, 'kie', 'Học Kịch Bản Mẫu', resObj.credits, resObj.tokens);

                await saveLearnedStyle(projPath, { url: link, transcript: transcript, structure: resObj.structure });
                
                sendLog(`[THÀNH CÔNG] Hệ thống đã "Nhập Môn" được phong cách kịch bản này!`, 'success');
                resolve({success: true});
            } catch (e) {
                sendLog(`[LỖI AI] ${e.message}`, 'error');
                resolve({success:false, error: e.message});
            } finally {
                await fs.unlink(tempMp3).catch(()=>{});
            }
        });
    });
});

ipcMain.handle('pipeline:runAuto', async (e, n, aiConfig, voiceConfig, promptText, c, productInfo, d, subConfig, maxCon, customOut) => {
    const apiKey = typeof aiConfig === 'string' ? aiConfig : aiConfig?.apiKey;
    if (!n || !apiKey) return { success: false };
    
    sendLog(`--- KHỞI ĐỘNG DÂY CHUYỀN AUTO (${c} VIDEO) ---`, 'success');
    const projPath = path.join(WORKSPACE_PATH, n);
    
    const learnedStyles = await getLearnedStyles(projPath);
    const history = await getScriptHistory(projPath);
    const sources = await getProjectSources(projPath);
    
    let metaContext = "";
    for (const src of sources) {
        if (src.status === 'done') {
            const meta = await getMetadata(projPath, src.fileName);
            metaContext += `- File [${src.fileName}]: Nội dung: ${meta.MainContent||''} | Mục đích: ${meta.Purpose||''}\n`;
        }
    }

    let totalTasks = c * 3;
    let completedTasks = 0;
    
    const updateGlobal = () => {
        completedTasks++;
        const pct = Math.round((completedTasks / totalTasks) * 100);
        mainWindow.webContents.send('global-progress', pct);
    };

    let activeRenders = 0;
    let renderQueue = [];

    const processRenderQueue = async () => {
        if (global.isProcessStopped || activeRenders >= maxCon || renderQueue.length === 0) return;
        
        activeRenders++;
        const { scriptObj } = renderQueue.shift();
        
        try {
            sendLog(`[Render Video] ${scriptObj.id}: Bắt đầu trộn Timeline...`);
            // Bắn tín hiệu tạo Skeleton Card trên UI
            if (mainWindow) mainWindow.webContents.send('render-start', { id: scriptObj.id });

            const tlObj = await buildTimeline(projPath, scriptObj.content, scriptObj.voicePath, scriptObj.srtPath, apiKey); 
            const costRender = await logApiUsage(n, 'kie', 'Xếp Cảnh Video (Timeline)', tlObj.credits, tlObj.tokens);
            
            let config = await getProjectConfig(projPath) || {};
            config.renderCount = (config.renderCount || 0) + 1;
            await saveProjectConfig(projPath, config);
            
            sendLog(`[Render Video] ${scriptObj.id}: FFMPEG đang chạy...`);
            const filePath = await renderFinalVideo(projPath, config.projectName || n, config.renderCount, tlObj.timeline, scriptObj.voicePath, scriptObj.srtPath, subConfig, customOut);
            
            // LƯU TRỌN GÓI GIÁ VỐN SẢN XUẤT
            const totalCost = (scriptObj.costText || 0) + (scriptObj.costVoice || 0) + costRender;
            const costDbObj = { text: scriptObj.costText || 0, voice: scriptObj.costVoice || 0, render: costRender, total: totalCost };
            await fs.writeFile(filePath + '.meta.json', JSON.stringify(costDbObj), 'utf8');

            sendLog(`[HOÀN TẤT VIDEO] ${path.basename(filePath)} | Giá: ${totalCost.toLocaleString('vi-VN')}đ`, 'success');
            
            scriptObj.isRendered = true;
            await saveScriptRecord(projPath, scriptObj);
            
            updateGlobal();
            if(mainWindow) mainWindow.webContents.send('render-done');
        } catch(err) {
            sendLog(`[LỖI RENDER] ${scriptObj.id}: ${err.message}`, 'error');
            updateGlobal(); 
            if(mainWindow) mainWindow.webContents.send('render-done'); // Gọi để refresh mât skeleton
        } finally {
            activeRenders--;
            processRenderQueue(); 
        }
    };

    for(let i=0; i<c; i++) {
        if (global.isProcessStopped) break;

        sendLog(`[Auto] Đang tư duy Kịch Bản số ${i+1}/${c}...`);
        try {
            const scriptResObj = await generateNewScripts(apiKey, promptText, learnedStyles, history, metaContext, 1, productInfo, d, i); 
            if (!scriptResObj.scripts || scriptResObj.scripts.length === 0) throw new Error("AI không nhả chữ.");
            
            const costText = await logApiUsage(n, 'kie', `Tạo Kịch Bản Auto ${i+1}`, scriptResObj.credits, scriptResObj.tokens);

            const scriptData = { id: 'SCRIPT_' + Date.now() + '_' + i, content: scriptResObj.scripts[0], createdAt: new Date().toISOString(), isRendered: false, costText: costText };
            await saveScriptRecord(projPath, scriptData);
            updateGlobal(); 
            if (mainWindow) mainWindow.webContents.send('script-generated', scriptData);
            
            (async (sData) => {
                if (global.isProcessStopped) return;
                
                sendLog(`[Voice] Đang thu âm cho ${sData.id}...`);
                try {
                    let voiceRes;
                    let costVoice = 0;
                    if (voiceConfig.provider === 'everai') {
                        voiceRes = await generateEverAIVoice(sData.content, voiceConfig.v, voiceConfig.s, voiceConfig.vo, voiceConfig.pi, voiceConfig.kEver, path.join(projPath, '04_Voice'));
                        costVoice = await logApiUsage(n, 'ever', 'Lồng Tiếng EverAI', voiceRes.usage);
                    } else {
                        voiceRes = await generateVoiceFile(sData.content, voiceConfig.v, voiceConfig.s, voiceConfig.vo, voiceConfig.pi, voiceConfig.kLar, path.join(projPath, '04_Voice'));
                        costVoice = await logApiUsage(n, 'lar', 'Lồng Tiếng LarVoice', voiceRes.usage);
                    }
                    
                    sData.voicePath = voiceRes.filePath;
                    sData.srtPath = voiceRes.srtPath;
                    sData.costVoice = costVoice; // Cập nhật phí
                    await saveScriptRecord(projPath, sData);
                    sendLog(`[Voice] ${sData.id} hoàn tất! Đẩy qua bộ phận Render...`, 'success');
                    updateGlobal(); 
                    
                    if (global.isProcessStopped) return;
                    renderQueue.push({ scriptObj: sData });
                    processRenderQueue();
                    
                } catch (vErr) {
                    sendLog(`[LỖI VOICE] ${sData.id}: ${vErr.message}`, 'error');
                    updateGlobal(); updateGlobal(); 
                }
            })(scriptData).catch(err => console.error(err));

        } catch (sErr) {
            sendLog(`[LỖI SCRIPT] số ${i+1}: ${sErr.message}`, 'error');
            updateGlobal(); updateGlobal(); updateGlobal(); 
        }
    }

    return { success: true };
});

ipcMain.handle('script:generateBatch', async (e, n, aiConfig, p, s, c, productInfo, d) => {
    const apiKey = typeof aiConfig === 'string' ? aiConfig : aiConfig?.apiKey;
    if (!n || !apiKey) return { success: false, error: "Thiếu API Key" };
    try {
        const projPath = path.join(WORKSPACE_PATH, n);
        const learnedStyles = await getLearnedStyles(projPath);
        const history = await getScriptHistory(projPath);
        const sources = await getProjectSources(projPath);
        
        let metaContext = "";
        for (const src of sources) {
            if (src.status === 'done') {
                const meta = await getMetadata(projPath, src.fileName);
                metaContext += `- File [${src.fileName}]: Nội dung: ${meta.MainContent||''} | Mục đích: ${meta.Purpose||''}\n`;
            }
        }
        
        let totalCreated = 0;
        for(let i=0; i<c; i++) {
            if(global.isProcessStopped) break;
            sendProgress('script', Math.round(((i) / c) * 100)); 
            
            const resObj = await generateNewScripts(apiKey, p, learnedStyles, history, metaContext, 1, productInfo, d, i); 
            const costText = await logApiUsage(n, 'kie', 'Tạo Kịch Bản Thủ Công', resObj.credits, resObj.tokens);

            if (resObj.scripts && resObj.scripts.length > 0) {
                const scriptData = { id: 'SCRIPT_' + Date.now() + '_' + i, content: resObj.scripts[0], createdAt: new Date().toISOString(), isRendered: false, costText: costText };
                await saveScriptRecord(projPath, scriptData);
                totalCreated++;
                if (mainWindow) mainWindow.webContents.send('script-generated', scriptData);
            }
        }
        sendProgress('script', 100);
        return { success: true, count: totalCreated };
    } catch (err) { 
        sendLog(`[LỖI API TEXT] ${err.message}`, 'error');
        return { success: false, error: err.message }; 
    }
});

ipcMain.handle('script:list', async (e, n) => { 
    if (!n) return []; 
    try { return await listScripts(path.join(WORKSPACE_PATH, n)); } catch (err) { return []; } 
});

ipcMain.handle('script:saveRecord', async (e, n, d) => { if (!n) return {success: false}; try { await saveScriptRecord(path.join(WORKSPACE_PATH, n), d); return { success: true }; } catch (err) { return { success: false, error: err.message }; } });
ipcMain.handle('script:deleteRecord', async (e, n, i) => { if (!n) return {success: false}; try { await deleteScriptRecord(path.join(WORKSPACE_PATH, n), i); return { success: true }; } catch (err) { return { success: false, error: err.message }; } });

ipcMain.handle('voice:list', async (e, k) => { return await getVoices(k); });

ipcMain.handle('voice:generateBatch', async (e, n, voiceConfig) => {
    if (!n) return { success: false };
    try {
        const p = path.join(WORKSPACE_PATH, n);
        const scripts = await listScripts(p);
        const scriptsToGen = scripts.filter(x => !x.voicePath);
        if(scriptsToGen.length === 0) return { success: true, count: 0 };

        let doneCount = 0;
        for (let i = 0; i < scriptsToGen.length; i++) {
            if (global.isProcessStopped) break;
            const script = scriptsToGen[i];
            sendProgress('voice', Math.round(((i) / scriptsToGen.length) * 100));
            
            try {
                let res; let costVoice = 0;
                if (voiceConfig.provider === 'everai') {
                    res = await generateEverAIVoice(script.content, voiceConfig.v, voiceConfig.s, voiceConfig.vo, voiceConfig.pi, voiceConfig.kEver, path.join(p, '04_Voice'));
                    costVoice = await logApiUsage(n, 'ever', 'Lồng Tiếng Thủ Công', res.usage);
                } else {
                    res = await generateVoiceFile(script.content, voiceConfig.v, voiceConfig.s, voiceConfig.vo, voiceConfig.pi, voiceConfig.kLar, path.join(p, '04_Voice'));
                    costVoice = await logApiUsage(n, 'lar', 'Lồng Tiếng Thủ Công', res.usage);
                }
                
                script.voicePath = res.filePath;
                script.srtPath = res.srtPath;
                script.costVoice = costVoice;
                await saveScriptRecord(p, script);
                doneCount++;
            } catch (voiceErr) {
                sendLog(`Lỗi tại kịch bản ${script.id}: ${voiceErr.message}`, 'error');
            }
        }
        sendProgress('voice', 100);
        return { success: true, count: doneCount };
    } catch (err) { return { success: false, error: err.message }; }
});

ipcMain.handle('video:renderBatch', async (e, n, aiConfig, sub, targetIds, maxConcurrent = 3, customOut = null) => {
    const apiKey = typeof aiConfig === 'string' ? aiConfig : aiConfig?.apiKey;
    if (!n || !apiKey) return { success: false, error: "Thiếu API Key" };
    try {
        const p = path.join(WORKSPACE_PATH, n);
        const scripts = await listScripts(p);
        
        let totalProcessed = 0;
        for (let i = 0; i < targetIds.length; i += maxConcurrent) {
            if(global.isProcessStopped) break;
            const chunkIds = targetIds.slice(i, i + maxConcurrent);
            
            const promises = chunkIds.map(async (id) => {
                const script = scripts.find(x => x.id === id);
                if (script && script.voicePath && script.srtPath) {
                    try {
                        if (mainWindow) mainWindow.webContents.send('render-start', { id: script.id });

                        const tlObj = await buildTimeline(p, script.content, script.voicePath, script.srtPath, apiKey);
                        const costRender = await logApiUsage(n, 'kie', 'Xếp Cảnh Thủ Công', tlObj.credits, tlObj.tokens);
                        
                        let config = await getProjectConfig(p) || {};
                        config.renderCount = (config.renderCount || 0) + 1;
                        await saveProjectConfig(p, config);
                        
                        const filePath = await renderFinalVideo(p, config.projectName || n, config.renderCount, tlObj.timeline, script.voicePath, script.srtPath, sub, customOut);
                        
                        const totalCost = (script.costText || 0) + (script.costVoice || 0) + costRender;
                        const costDbObj = { text: script.costText || 0, voice: script.costVoice || 0, render: costRender, total: totalCost };
                        await fs.writeFile(filePath + '.meta.json', JSON.stringify(costDbObj), 'utf8');

                        script.isRendered = true;
                        await saveScriptRecord(p, script);
                        
                        totalProcessed++;
                        sendProgress('render', Math.round((totalProcessed / targetIds.length) * 100));
                        return true;
                    } catch(err) {
                        sendLog(`[Video ${id}] LỖI RENDER: ${err.message}`, 'error');
                        totalProcessed++;
                        sendProgress('render', Math.round((totalProcessed / targetIds.length) * 100));
                        return false;
                    }
                }
            });
            await Promise.all(promises); 
        }
        sendProgress('render', 100);
        return { success: true };
    } catch (err) { return { success: false, error: err.message }; }
});

ipcMain.handle('ai:cameraSuggest', async (e, projectName, links, count, apiKey) => {
    const cleanK = typeof apiKey === 'string' ? apiKey : apiKey?.apiKey;
    if (!projectName || !cleanK) return { success: false, error: "Thiếu dữ liệu (Tên dự án hoặc API Key)" };
    const tempBaseDir = path.join(WORKSPACE_PATH, '.temp_ai_camera');
    await fs.mkdir(tempBaseDir, { recursive: true }).catch(()=>{});
    let analyzedSummaries = [];
    const { default: axios } = await import('axios'); 
    try {
        sendLog(`Bắt đầu xử lý AI Camera. Khởi tạo thư mục nháp tại ${tempBaseDir}...`);
        for (let i = 0; i < links.length; i++) {
            if(!links[i].trim()) continue;
            sendLog(`---------------------------------------`);
            sendLog(`[Video ${i+1}/${links.length}] Bắt đầu tải và phân tích độc lập...`);
            const outVideo = path.join(tempBaseDir, `ref_vid_${i+1}.mp4`);
            const tempFramesDir = path.join(tempBaseDir, `frames_${i+1}`);
            try {
                await new Promise((resolve, reject) => {
                    const dlCmd = `yt-dlp -f "best" --no-playlist -o "${outVideo}" "${links[i]}"`;
                    exec(dlCmd, (err) => { if (err) return reject(new Error(`yt-dlp failed: ${err.message}`)); resolve(); });
                });
                await fs.mkdir(tempFramesDir, { recursive: true });
                sendLog(`[Video ${i+1}] Đang trích xuất hình ảnh...`);
                await new Promise((resolve, reject) => {
                    const ffmpegCmd = `ffmpeg -y -i "${outVideo}" -f image2 -q:v 2 -vf "fps=1" -t 20 "img-%04d.jpg"`;
                    exec(ffmpegCmd, { cwd: tempFramesDir }, (err, stdout, stderr) => { if (err) return reject(new Error(`FFmpeg failed: ${err.message}`)); resolve(); });
                });
                const files = await fs.readdir(tempFramesDir);
                const imageFiles = files.filter(f => f.startsWith('img-') && f.endsWith('.jpg')).sort();
                if(imageFiles.length === 0) throw new Error("Video này chỉ có âm thanh, không có hình ảnh.");
                let framesToSend = [];
                const MAX_FRAMES = 12;
                if (imageFiles.length <= MAX_FRAMES) framesToSend = imageFiles;
                else {
                    const step = imageFiles.length / MAX_FRAMES;
                    for (let j = 0; j < MAX_FRAMES; j++) framesToSend.push(imageFiles[Math.floor(j * step)]);
                }
                sendLog(`[Video ${i+1}] Gửi ${framesToSend.length} khung hình lên AI...`);
                const contentArray = [{ "type": "input_text", "text": "Phân tích chuỗi hình ảnh của video TikTok/Shorts này. Hãy liệt kê các CẢNH QUAY (Scene), GÓC MÁY (Camera Angle) và HÀNH ĐỘNG (Action) đang diễn ra. Trả lời cực kỳ ngắn gọn." }];
                for (const f of framesToSend) {
                    const b64 = (await fs.readFile(path.join(tempFramesDir, f))).toString('base64');
                    contentArray.push({ "type": "input_image", "image_url": `data:image/jpeg;base64,${b64}` });
                }
                const response = await axios.post(
                    'https://api.kie.ai/codex/v1/responses',
                    { model: "gpt-5-6-luna", input: [{ role: "user", content: contentArray }], reasoning: { effort: "high" } },
                    { headers: { 'Authorization': `Bearer ${cleanK}`, 'Content-Type': 'application/json' } }
                );
                
                let summary = "";
                let jsonObj = response.data;
                if (typeof response.data === 'string') {
                    const lines = response.data.split('\n');
                    for (let x = lines.length - 1; x >= 0; x--) {
                        if (lines[x].startsWith('data: ')) {
                            try {
                                let parsed = JSON.parse(lines[x].substring(6).trim());
                                if (parsed.response || parsed.output) { jsonObj = parsed; break; }
                            } catch(e) {}
                        }
                    }
                }
                const outArr = jsonObj?.response?.output || jsonObj?.output;
                if (outArr && Array.isArray(outArr)) {
                    const msg = outArr.slice().reverse().find(o => o.type === 'message' && o.phase === 'final_answer') || outArr.slice().reverse().find(o => o.type === 'message');
                    if (msg && msg.content && Array.isArray(msg.content)) {
                        const textNode = msg.content.find(c => c.type === 'output_text');
                        if (textNode) summary = textNode.text;
                    }
                }

                analyzedSummaries.push(`--- VIDEO MẪU SỐ ${i+1} ---\n${summary}`);
                
                const creds = jsonObj?.credits_consumed || jsonObj?.response?.credits_consumed || 0;
                const tokens = jsonObj?.usage?.total_tokens || jsonObj?.response?.usage?.total_tokens || 0;
                await logApiUsage(projectName, 'kie', `AI Camera Phân Tích Mẫu ${i+1}`, creds, tokens);

                sendLog(`[Video ${i+1}] Phân tích thành công!`);
            } catch (err) { sendLog(`[Video ${i+1}] Lỗi: Bỏ qua video này. (${err.message})`, 'error'); }
        }
        if (analyzedSummaries.length === 0) throw new Error("Thất bại toàn tập: Không có video nào tải và trích xuất hình ảnh thành công.");
        sendLog(`---------------------------------------`);
        sendLog(`Đã phân tích xong ${analyzedSummaries.length} video. Bắt đầu tổng hợp và thiết kế ${count} góc máy...`);
        const finalPrompt = `Bạn là Đạo Diễn Hình Ảnh (DOP) và Đạo Diễn Nội Dung (Content Director) xuất sắc.
Dưới đây là tóm tắt dữ liệu hình ảnh bóc tách từ các video mẫu Viral:
${analyzedSummaries.join('\n\n')}
Nhiệm vụ: Dựa vào phong cách, cấu trúc, bối cảnh, nhịp điệu của các video trên, hãy SÁNG TẠO và GỢI Ý cho tôi ĐÚNG ${count} GÓC MÁY (SHOTS) để tôi tự xách điện thoại đi quay bắt chước theo phong cách này.
TRẢ VỀ DUY NHẤT JSON KHÔNG CÓ BẤT KỲ VĂN BẢN NÀO KHÁC BÊN NGOÀI:
{
  "analysis": "Tóm tắt ngắn gọn cấu trúc kịch bản và phong cách quay (Vibe) chung của các video mẫu.",
  "suggested_shots": [
    {
      "shot_number": 1,
      "camera_angle": "Tên góc quay (Cận cảnh, Toàn cảnh, Góc cao...)",
      "action": "Hành động của người hoặc vật thể",
      "duration": "Thời lượng ước tính (ví dụ: 2 giây)"
    }
  ]
}`;
        const finalResponse = await axios.post(
            'https://api.kie.ai/codex/v1/responses',
            { model: "gpt-5-6-luna", input: [{ role: "user", content: [{ type: "input_text", text: finalPrompt }] }], reasoning: { effort: "high" } },
            { headers: { 'Authorization': `Bearer ${cleanK}`, 'Content-Type': 'application/json' } }
        );
        
        let resultContent = "";
        let finalJsonObj = finalResponse.data;
        if (typeof finalResponse.data === 'string') {
            const lines = finalResponse.data.split('\n');
            for (let x = lines.length - 1; x >= 0; x--) {
                if (lines[x].startsWith('data: ')) {
                    try {
                        let parsed = JSON.parse(lines[x].substring(6).trim());
                        if (parsed.response || parsed.output) { finalJsonObj = parsed; break; }
                    } catch(e) {}
                }
            }
        }

        const outArr = finalJsonObj?.response?.output || finalJsonObj?.output;
        if (outArr && Array.isArray(outArr)) {
            const msg = outArr.slice().reverse().find(o => o.type === 'message' && o.phase === 'final_answer') || outArr.slice().reverse().find(o => o.type === 'message');
            if (msg && msg.content && Array.isArray(msg.content)) {
                const textNode = msg.content.find(c => c.type === 'output_text');
                if (textNode) resultContent = textNode.text;
            }
        }

        const finalCreds = finalJsonObj?.credits_consumed || finalJsonObj?.response?.credits_consumed || 0;
        const finalTokens = finalJsonObj?.usage?.total_tokens || finalJsonObj?.response?.usage?.total_tokens || 0;
        await logApiUsage(projectName, 'kie', `AI Camera Tổng Hợp Dàn Ý`, finalCreds, finalTokens);

        const resultJSON = JSON.parse(resultContent.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/g, '').trim());
        sendLog(`AI Camera đã hoàn tất thiết kế ${resultJSON.suggested_shots?.length || 0} góc máy!`, 'success');
        return { success: true, data: resultJSON };
    } catch (err) {
        sendLog(`Lỗi Tổng hợp AI Camera: ${err.message}`, 'error');
        return { success: false, error: err.message };
    } finally {
        await fs.rm(tempBaseDir, { recursive: true, force: true }).catch(()=>{});
    }
});

ipcMain.handle('video:listFinals', async (e, n, customOut) => { 
    if (!n) return []; 
    try { return await getFinalVideos(path.join(WORKSPACE_PATH, n), customOut); } catch (err) { return []; } 
});