// File path: src/services/openai_text.js
const axios = require('axios');

function extractKieResponse(responseData) {
    let jsonObj = responseData;
    
    if (typeof responseData === 'string') {
        try {
            jsonObj = JSON.parse(responseData);
        } catch(e) {
            const lines = responseData.split('\n');
            for (let i = lines.length - 1; i >= 0; i--) {
                if (lines[i].startsWith('data: ')) {
                    try {
                        let parsed = JSON.parse(lines[i].substring(6).trim());
                        if (parsed.response || parsed.output) {
                            jsonObj = parsed;
                            break;
                        }
                    } catch(err2) {}
                }
            }
        }
    }

    const outArr = jsonObj?.response?.output || jsonObj?.output;
    if (!outArr || !Array.isArray(outArr)) return { content: "", credits: 0, tokens: 0 };
    
    const msg = outArr.slice().reverse().find(o => o.type === 'message' && o.phase === 'final_answer') 
             || outArr.slice().reverse().find(o => o.type === 'message');
             
    if (!msg || !msg.content || !Array.isArray(msg.content)) return { content: "", credits: 0, tokens: 0 };
    
    const textNode = msg.content.find(c => c.type === 'output_text');
    
    const credits = jsonObj?.credits_consumed || jsonObj?.response?.credits_consumed || 0;
    const tokens = jsonObj?.usage?.total_tokens || jsonObj?.response?.usage?.total_tokens || 0;

    return { 
        content: textNode ? textNode.text : "", 
        credits: credits,
        tokens: tokens 
    };
}

async function analyzeScriptStructure(apiKey, rawTranscript, cameraCount = 10) {
    const prompt = `Dưới đây là lời thoại bóc băng (STT) của một video TikTok/Shorts cực kỳ Viral.
Nhiệm vụ của bạn là đóng vai 1 CHUYÊN GIA ĐẠO DIỄN NỘI DUNG VÀ HÌNH ẢNH. Hãy làm các việc sau:

1. Đặt Tên Phong Cách: Tự nghĩ ra một cái tên thật ngắn gọn, kêu tai để miêu tả văn phong này (VD: "Chê trước khen sau", "Kể chuyện tâm sự thầm kín", "Review chuyên môn căng đét").
2. Phân Tích Cấu Trúc Text: Cách giật tít, cách triển khai thân bài, nhịp điệu, giọng văn (đanh đá, hài hước, hay nhẹ nhàng).
3. Gợi ý Góc Máy (Camera Direction): Dựa vào tư duy hình ảnh và khớp với Lời thoại trên, hãy chia lời thoại thành CÁC CẢNH và gợi ý cho tôi ĐÚNG ${cameraCount} góc máy (Shots) để tôi tự xách điện thoại đi quay theo.

[LỜI THOẠI GỐC CỦA VIDEO]: 
"${rawTranscript}"

TRẢ VỀ DUY NHẤT KHUÔN DẠNG JSON SAU, KHÔNG GIẢI THÍCH BẤT CỨ TỪ NÀO BÊN NGOÀI:
{
  "style_name": "Tên phong cách bạn tự đặt",
  "structure": "Đoạn văn phân tích cấu trúc kịch bản và tone giọng...",
  "suggested_shots": [
    {
      "shot_number": 1,
      "camera_angle": "Góc cận/Góc toàn/Góc từ trên xuống...",
      "action": "Miêu tả hành động của người hoặc vật thể trong khung hình",
      "matching_text": "Trích dẫn 1 câu thoại ngắn trong kịch bản khớp với cảnh này"
    }
  ]
}`;

    const payload = {
        model: "gpt-5-6-luna",
        input: [{ role: "user", content: [{ type: "input_text", text: prompt }] }],
        reasoning: { effort: "high" }
    };

    const response = await axios.post('https://api.kie.ai/codex/v1/responses', payload, {
        headers: { 'Authorization': `Bearer ${apiKey.trim()}`, 'Content-Type': 'application/json' }
    });
    
    let resObj = extractKieResponse(response.data);
    if (!resObj.content) throw new Error("API Kie.ai trả về chuỗi rỗng.");

    let cleanJSON = resObj.content.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/g, '').trim();
    const jsonMatch = cleanJSON.match(/\{[\s\S]*\}/);
    if (jsonMatch) cleanJSON = jsonMatch[0];

    return { data: JSON.parse(cleanJSON), credits: resObj.credits, tokens: resObj.tokens };
}

async function generateNewScripts(apiKey, userPrompt, specificStyleObj, historyText, metadataContext, count, productInfo, duration) {
    if (!apiKey) throw new Error("Chưa cấu hình API Key Kie.ai.");

    let targetWords = 100;
    if (duration === '60s') targetWords = 200;
    if (duration === '90s') targetWords = 320; 

    let styleConstraint = "";
    if (specificStyleObj && specificStyleObj.structure) {
        styleConstraint = `(BẮT BUỘC SAO CHÉP Y HỆT CẤU TRÚC VÀ VĂN PHONG TỪ MẪU DƯỚI ĐÂY:
Tên phong cách: ${specificStyleObj.name}
Cấu trúc phân tích: ${specificStyleObj.structure}
Lời thoại gốc: ${specificStyleObj.transcript}
-> CTA hướng về sự hoàn thiện, sạch sẽ).`;
    } else {
        styleConstraint = `Hãy tự do sáng tạo văn phong đa dạng (Kịch tính, Hài hước, Chê trước khen sau, Review chân thực...) để làm nổi bật sản phẩm.`;
    }

    const systemPrompt = `
# VAI TRÒ
Bạn là một KOC Top 1 TikTok có doanh thu khủng, sở hữu khả năng storytelling đỉnh cao, ngôn từ đời thường, chân thực và cực kỳ cuốn hút.

# NHIỆM VỤ
Viết ${count} kịch bản video review sản phẩm dựa trên thông tin và tài nguyên được cung cấp.
- Độ dài kịch bản: Khoảng ${targetWords} từ (phù hợp thời lượng voice đọc vừa đủ ${duration}).

# QUY TẮC VIẾT LỜI THOẠI (THIẾT QUÂN LUẬT)
- Nhịp điệu và Dấu câu (CỰC QUAN TRỌNG): BẮT BUỘC sử dụng dấu phẩy (,) và dấu chấm (.) để tạo nhịp ngắt nghỉ tự nhiên cho giọng đọc AI (TTS) lấy hơi. TUYỆT ĐỐI KHÔNG viết một lèo không dấu.
- Ký hiệu: KHÔNG dùng icon/emoji hay các ký tự lạ khác ngoài dấu câu cơ bản.
- Quy tắc chữ số: BẮT BUỘC viết tất cả các số bằng chữ (Ví dụ: viết "bảy trong một" thay vì "7in1", "ba mươi giây" thay vì "30s").
- Chống ảo giác: CHỈ viết về những vật thể, hành động có mặt trong [TÀI NGUYÊN VIDEO]. Tuyệt đối KHÔNG bịa đặt thêm thiết bị hoặc hành động khác.
- Luật chốt sale (CTA): Ở cuối kịch bản, dùng từ ngữ mô tả sự sạch sẽ, hoàn thiện để Editor ghép video thành quả vào.
${historyText ? `- Tránh trùng lặp ý tưởng: KHÔNG viết lại theo hướng lười biếng, không lặp lại mô típ của các ý tưởng cũ sau:\n${historyText}` : ''}

# TÀI LIỆU KHẢO SÁT CHẤT LIỆU
[THÔNG TIN SẢN PHẨM]
- Tên SP: ${productInfo?.name || "Không rõ"}
- Giá: ${productInfo?.price || "Không rõ"}
- Mô tả: ${productInfo?.desc || "Không rõ"}

[TÀI NGUYÊN VIDEO HIỆN CÓ]
${metadataContext}

[DỮ LIỆU VĂN PHONG BẮT CHƯỚC]
${styleConstraint}
Yêu cầu riêng từ đạo diễn: ${userPrompt || "Không có"}

# ĐỊNH DẠNG ĐẦU RA (MẪU JSON BẮT BUỘC)
Trả về duy nhất định dạng mảng JSON theo cấu trúc sau, không kèm lời giải thích ngoài JSON:
{
  "scripts": [
    {
      "angle": "Tên góc nhìn của kịch bản",
      "content": "Lời thoại..."
    }
  ]
}
    `.trim();

    try {
        const payload = {
            model: "gpt-5-6-luna",
            input: [{ role: "user", content: [{ type: "input_text", text: systemPrompt }] }],
            reasoning: { effort: "high" }
        };

        const response = await axios.post('https://api.kie.ai/codex/v1/responses', payload, {
            headers: { 'Authorization': `Bearer ${apiKey.trim()}`, 'Content-Type': 'application/json' }
        });

        let resObj = extractKieResponse(response.data);
        if (!resObj.content) throw new Error("API Kie.ai trả về chuỗi rỗng.");

        let cleanJSON = resObj.content.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/g, '').trim();
        const jsonMatch = cleanJSON.match(/\{[\s\S]*\}/);
        if (jsonMatch) cleanJSON = jsonMatch[0];

        const parsedJSON = JSON.parse(cleanJSON);
        
        let finalScripts = [];
        if (parsedJSON.scripts && Array.isArray(parsedJSON.scripts)) {
            finalScripts = parsedJSON.scripts.map(s => {
                if (typeof s === 'object' && s.content) return s.content;
                if (typeof s === 'string') return s;
                return "";
            }).filter(s => s.length > 0);
        }
        
        return { scripts: finalScripts, credits: resObj.credits, tokens: resObj.tokens };
    } catch (error) {
        throw new Error("Lỗi khi sinh kịch bản: " + (error.response?.data?.error?.message || error.message));
    }
}

module.exports = { generateNewScripts, analyzeScriptStructure };