// File path: src/services/openai_vision.js
const axios = require('axios');
const path = require('path');
const fs = require('fs/promises');
const os = require('os');
const crypto = require('crypto');
const { exec } = require('child_process');

function extractKieResponse(responseData) {
    let jsonObj = responseData;
    
    if (typeof responseData === 'string') {
        try {
            jsonObj = JSON.parse(responseData);
        } catch(e) {
            const lines = responseData.split('\n');
            for (let i = lines.length - 1; i >= 0; i--) {
                if (lines[i].startsWith('data: ')) {
                    try {
                        let parsed = JSON.parse(lines[i].substring(6).trim());
                        if (parsed.output || parsed.response) {
                            jsonObj = parsed;
                            break;
                        }
                    } catch(err2) {}
                }
            }
        }
    }

    if (jsonObj && jsonObj.code && jsonObj.msg) {
        throw new Error(`[Từ máy chủ Kie.ai]: ${jsonObj.msg}`);
    }

    const outArr = jsonObj?.output || jsonObj?.response?.output;
    if (!outArr || !Array.isArray(outArr)) {
        throw new Error("API Kie.ai không trả về mảng 'output' hợp lệ.");
    }
    
    const msg = outArr.slice().reverse().find(o => o.type === 'message');
             
    if (!msg || !msg.content || !Array.isArray(msg.content)) {
        throw new Error("Không tìm thấy nội dung Text trong mảng 'output'.");
    }
    
    const textNode = msg.content.find(c => c.type === 'output_text');
    
    const credits = jsonObj?.credits_consumed || jsonObj?.response?.credits_consumed || 0;
    const tokens = jsonObj?.usage?.total_tokens || jsonObj?.response?.usage?.total_tokens || 0;

    return { 
        content: textNode ? textNode.text : "", 
        credits: credits,
        tokens: tokens 
    };
}

async function extractFrames(videoPath, tempDir, targetFps) {
    return new Promise((resolve, reject) => {
        const ffmpegCmd = `ffmpeg -y -i "${videoPath}" -f image2 -q:v 2 -vf "fps=${targetFps}" "img-%04d.jpg"`;
        exec(ffmpegCmd, { cwd: tempDir }, (err, stdout, stderr) => {
            if (err) {
                return reject(new Error(`FFmpeg extraction failed: ${err.message}`));
            }
            resolve();
        });
    });
}

async function analyzeVideoSource(videoPath, apiKey, productInfo, targetFps = 15) {
    if (!apiKey || apiKey.trim() === '') throw new Error("Chưa cấu hình API Key.");
    const cleanKey = apiKey.trim();

    const tempDirName = `aivideo_frames_${crypto.randomBytes(4).toString('hex')}`;
    const tempDir = path.join(os.tmpdir(), tempDirName);

    try {
        await fs.mkdir(tempDir, { recursive: true });
        await extractFrames(videoPath, tempDir, targetFps);

        const files = await fs.readdir(tempDir);
        const imageFiles = files.filter(f => f.startsWith('img-') && f.endsWith('.jpg')).sort();
        
        let framesToSend = [];
        const MAX_FRAMES = 25; 
        if (imageFiles.length <= MAX_FRAMES) {
            framesToSend = imageFiles;
        } else {
            const step = imageFiles.length / MAX_FRAMES;
            for (let i = 0; i < MAX_FRAMES; i++) {
                framesToSend.push(imageFiles[Math.floor(i * step)]);
            }
        }

        if (framesToSend.length === 0) throw new Error("Không thể trích xuất khung hình từ video.");

        let sysPrompt = `Bạn là một CHUYÊN GIA PHÂN TÍCH HÀNH ĐỘNG (ACTION TRACKER). 
Tôi cung cấp cho bạn các khung hình được trích xuất đều từ ĐẦU ĐẾN CUỐI của một video clip.

[THÔNG TIN SẢN PHẨM CHÍNH TRONG VIDEO]:
- Tên sản phẩm: ${productInfo?.name || "Không rõ"}
- Giá tiền: ${productInfo?.price || "Không rõ"}
- Mô tả / Công dụng: ${productInfo?.desc || "Không rõ"}

🔥 LUẬT TỐI CAO BẮT BUỘC PHẢI TUÂN THEO 🔥:
1. KHI MÔ TẢ VẬT THỂ MÀ NGƯỜI TRONG VIDEO ĐANG CẦM, ĐANG SỬ DỤNG HOẶC TƯƠNG TÁC, BẠN **BẮT BUỘC PHẢI GỌI ĐÍCH DANH NÓ LÀ: "${productInfo?.name || "Sản phẩm"}"**.
2. TUYỆT ĐỐI KHÔNG DÙNG CÁC TỪ CHUNG CHUNG NHƯ: "vật dụng", "thiết bị", "đồ vật", "cái hộp". Đã có tên sản phẩm, PHẢI DÙNG TÊN ĐÓ!
3. CHỈ TẬP TRUNG 100% VÀO CHUYỂN ĐỘNG CỦA CON NGƯỜI VÀ VẬT THỂ. BỎ QUA BỐI CẢNH.

TRẢ VỀ DUY NHẤT JSON KHÔNG CÓ BẤT KỲ VĂN BẢN NÀO KHÁC BÊN NGOÀI:
{
  "MainContent": "Mô tả cực kỳ chi tiết chuỗi hành động diễn ra",
  "Description": "Tóm tắt hành động bằng 1 câu ngắn gọn",
  "Action": "Động từ chính",
  "Object": "Tên vật thể",
  "Scene": "Môi trường",
  "Camera": "Góc quay",
  "Purpose": "Mục đích hành động",
  "Keyword": "Danh sách từ khóa"
}`;

        const contentArray = [{ "type": "input_text", "text": sysPrompt }];
        for (const file of framesToSend) {
            const imageBuffer = await fs.readFile(path.join(tempDir, file));
            contentArray.push({
                "type": "input_image",
                "image_url": `data:image/jpeg;base64,${imageBuffer.toString('base64')}`
            });
        }

        const payload = {
            model: "gpt-5-6-luna",
            input: [{ role: "user", content: contentArray }],
            reasoning: { effort: "high" }
        };

        const response = await axios.post('https://api.kie.ai/codex/v1/responses', payload, {
            headers: { 'Authorization': `Bearer ${cleanKey}`, 'Content-Type': 'application/json' }
        });

        let resObj = extractKieResponse(response.data);
        if (!resObj.content) throw new Error("API từ chối phân tích ảnh này.");

        let cleanJSON = resObj.content.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/g, '').trim();
        const jsonMatch = cleanJSON.match(/\{[\s\S]*\}/);
        if (jsonMatch) cleanJSON = jsonMatch[0];

        return { meta: JSON.parse(cleanJSON), credits: resObj.credits, tokens: resObj.tokens };

    } catch (error) {
        let errMsg = error.message;
        if (error.response && error.response.data) {
            errMsg = typeof error.response.data === 'object' ? JSON.stringify(error.response.data) : error.response.data;
        }
        throw new Error(`API Vision lỗi: ${errMsg}`);
    } finally {
        await fs.rm(tempDir, { recursive: true, force: true }).catch(()=>{});
    }
}

module.exports = { analyzeVideoSource };