// File path: src/local_core/ffmpeg_render.js
const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const fs = require('fs/promises');
const os = require('os');
const crypto = require('crypto');
const { getAudioDuration } = require('./metadata_matcher');

function hexToAssColor(hex) {
    if (!hex) return '&H00FFFFFF';
    hex = String(hex).replace('#', '');
    if (hex.length === 6) {
        const r = hex.substring(0, 2);
        const g = hex.substring(2, 4);
        const b = hex.substring(4, 6);
        return `&H00${b}${g}${r}`;
    }
    return '&H00FFFFFF';
}

function processClip(inputPath, outputPath, duration, isFirstClip) {
    return new Promise((resolve, reject) => {
        let filterChain = 'scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30,format=yuv420p'; 
        if (isFirstClip) filterChain += `,fade=t=in:st=0:d=0.5`;

        ffmpeg()
            .input(inputPath)
            .inputOptions(['-stream_loop', '-1']) 
            .setStartTime(0)
            .setDuration(duration)
            .videoFilters(filterChain)
            .outputOptions(['-c:v libx264', '-crf 23', '-preset fast', '-pix_fmt yuv420p', '-an'])
            .save(outputPath)
            .on('end', resolve)
            .on('error', reject);
    });
}

function applyXfade(clip0, clip1, offsetTime, outputPath) {
    return new Promise((resolve, reject) => {
        ffmpeg()
            .input(clip0)
            .input(clip1)
            .complexFilter([`[0:v][1:v]xfade=transition=slideleft:duration=0.4:offset=${offsetTime}[v]`])
            .outputOptions(['-map [v]', '-c:v libx264', '-crf 23', '-preset fast', '-pix_fmt yuv420p', '-an'])
            .save(outputPath)
            .on('end', resolve)
            .on('error', reject);
    });
}

function concatAndMix(clipPaths, audioPath, srtPath, whooshPath, whooshDelay, totalAudioDur, finalOutput, subConfig) {
    return new Promise((resolve, reject) => {
        const listPath = path.join(os.tmpdir(), `list_${crypto.randomBytes(4).toString('hex')}.txt`);
        
        const fileContent = clipPaths.map(c => {
            if(!c) return '';
            return `file '${String(c).replace(/\\/g, '/')}'`;
        }).filter(Boolean).join('\n');
        
        require('fs').writeFileSync(listPath, fileContent);

        const safeSrtPath = srtPath ? String(srtPath).replace(/\\/g, '/').replace(/:/g, '\\:').replace(/,/g, '\\,') : '';
        
        const textColor = hexToAssColor(subConfig?.textColor || '#FFFFFF');
        const borderColor = hexToAssColor(subConfig?.borderColor || '#000000');
        const fontSize = subConfig?.fontSize || '24';
        const borderSize = subConfig?.borderSize || '2'; 
        const fontName = subConfig?.fontName || 'Arial'; 
        
        const styleAss = `FontName=${fontName},FontSize=${fontSize},PrimaryColour=${textColor},OutlineColour=${borderColor},BorderStyle=1,Outline=${borderSize},MarginV=60,Bold=1`;

        const cmd = ffmpeg().input(listPath).inputOptions(['-f concat', '-safe 0']).input(audioPath);
        
        if (whooshPath) cmd.input(whooshPath); 

        const fadeOutStart = Math.max(0, totalAudioDur - 0.5);
        
        let filterComplex = '';
        if (safeSrtPath) {
            filterComplex = `[0:v]subtitles='${safeSrtPath}':force_style='${styleAss}'[vsub];[vsub]fade=t=out:st=${fadeOutStart}:d=0.5[vout]`;
        } else {
            filterComplex = `[0:v]fade=t=out:st=${fadeOutStart}:d=0.5[vout]`;
        }

        if (whooshPath) {
            const delayMs = Math.floor(whooshDelay * 1000);
            filterComplex += `;[2:a]adelay=${delayMs}|${delayMs}[w];[1:a][w]amix=inputs=2:duration=first:dropout_transition=0[aout]`;
            cmd.outputOptions(['-map [vout]', '-map [aout]']);
        } else {
            cmd.outputOptions(['-map [vout]', '-map 1:a']);
        }

        cmd.complexFilter(filterComplex)
            .outputOptions(['-c:v libx264', '-crf 23', '-preset fast', '-pix_fmt yuv420p', '-c:a aac', '-b:a 128k', '-shortest'])
            .save(finalOutput)
            .on('end', async () => {
                await fs.unlink(listPath).catch(()=>{});
                resolve();
            })
            .on('error', reject);
    });
}

async function renderFinalVideo(projectPath, projectName, renderCount, timeline, voicePath, srtPath, subConfig, customOutputDir) {
    const tempDir = path.join(os.tmpdir(), `render_${crypto.randomBytes(4).toString('hex')}`);
    await fs.mkdir(tempDir, { recursive: true });

    try {
        const sourceDir = path.join(projectPath, '01_Source');
        const actualSourceFiles = await fs.readdir(sourceDir);
        let processedClips = [];
        let whooshPath = null;
        let whooshDelay = 0;
        
        const totalAudioDur = await getAudioDuration(voicePath);
        let sumDur = 0;
        for (let i = 0; i < timeline.length - 1; i++) sumDur += parseFloat(timeline[i].duration) || 2.0;
        let lastDur = parseFloat(timeline[timeline.length - 1].duration) || 2.0;
        
        if (sumDur + lastDur < totalAudioDur) lastDur = totalAudioDur - sumDur;
        timeline[timeline.length - 1].duration = lastDur + 0.5;

        for (let i = 0; i < timeline.length; i++) {
            const item = timeline[i];
            let fileName = String(item.file || item.filename || item.name || "");
            if (!actualSourceFiles.includes(fileName)) {
                let baseName = fileName.replace('SRC_', '').replace(/^0+/, '').replace('.mp4', '').replace('.mov', '');
                const matchedFile = actualSourceFiles.find(f => f.includes(baseName));
                fileName = matchedFile || actualSourceFiles[0]; 
            }

            const inputPath = path.join(sourceDir, fileName);
            const outputPath = path.join(tempDir, `clip_${i}.mp4`);
            let clipDuration = parseFloat(item.duration) || 2.0;
            const isFirstClip = (i === 0);
            if (isFirstClip && timeline.length > 1) clipDuration += 0.4;
            
            await processClip(inputPath, outputPath, clipDuration, isFirstClip);
            processedClips.push(outputPath);
        }

        const offsetTime = (parseFloat(timeline[0].duration) || 2); 
        if (processedClips.length > 1 && offsetTime >= 0.5) {
            const xfadeOutput = path.join(tempDir, `clip_0_1_xfaded.mp4`);
            whooshDelay = offsetTime;
            await applyXfade(processedClips[0], processedClips[1], offsetTime, xfadeOutput);
            
            if(subConfig?.customSoundPath) {
                const spath = path.join(tempDir, `sound.wav`);
                await fs.copyFile(subConfig.customSoundPath, spath).catch(()=>{});
                whooshPath = spath;
            }
            processedClips.splice(0, 2, xfadeOutput);
        }

        const outputDir = customOutputDir || path.join(projectPath, '07_Product');
        await fs.mkdir(outputDir, { recursive: true });
        
        const d = new Date();
        const dateStr = `${d.getFullYear()}${(d.getMonth()+1).toString().padStart(2,'0')}${d.getDate().toString().padStart(2,'0')}`;
        const countStr = String(renderCount || 1).padStart(4, '0'); 
        
        const cleanName = String(projectName || 'Video').replace(/[^a-zA-Z0-9]/g, '');
        const finalOutput = path.join(outputDir, `${cleanName}_${countStr}_${dateStr}.mp4`);
        
        await concatAndMix(processedClips, voicePath, srtPath, whooshPath, whooshDelay, totalAudioDur, finalOutput, subConfig);
        
        return finalOutput;
    } finally {
        await fs.rm(tempDir, { recursive: true, force: true }).catch(()=>{});
    }
}

module.exports = { renderFinalVideo };