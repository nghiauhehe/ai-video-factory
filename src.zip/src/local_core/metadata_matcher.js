// File path: src/local_core/metadata_matcher.js
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { getProjectSources, getMetadata } = require('../utils/file_system');
const path = require('path');
const fs = require('fs/promises');

function extractKieResponse(responseData) {
    let jsonObj = responseData;
    
    if (typeof responseData === 'string') {
        try {
            jsonObj = JSON.parse(responseData);
        } catch(e) {
            const lines = responseData.split('\n');
            for (let i = lines.length - 1; i >= 0; i--) {
                if (lines[i].startsWith('data: ')) {
                    try {
                        let parsed = JSON.parse(lines[i].substring(6).trim());
                        if (parsed.output || parsed.response) {
                            jsonObj = parsed;
                            break;
                        }
                    } catch(err2) {}
                }
            }
        }
    }

    if (jsonObj && jsonObj.code && jsonObj.msg) {
        throw new Error(`[Từ máy chủ Kie.ai]: ${jsonObj.msg}`);
    }

    const outArr = jsonObj?.output || jsonObj?.response?.output;
    if (!outArr || !Array.isArray(outArr)) {
        throw new Error("API Kie.ai không trả về mảng 'output' hợp lệ.");
    }
    
    const msg = outArr.slice().reverse().find(o => o.type === 'message');
             
    if (!msg || !msg.content || !Array.isArray(msg.content)) {
        throw new Error("Không tìm thấy nội dung Text trong mảng 'output'.");
    }
    
    const textNode = msg.content.find(c => c.type === 'output_text');
    
    const credits = jsonObj?.credits_consumed || jsonObj?.response?.credits_consumed || 0;
    const tokens = jsonObj?.usage?.total_tokens || jsonObj?.response?.usage?.total_tokens || 0;

    return { 
        content: textNode ? textNode.text : "", 
        credits: credits,
        tokens: tokens 
    };
}

function getAudioDuration(audioPath) {
    return new Promise((resolve) => {
        ffmpeg.ffprobe(audioPath, (err, metadata) => {
            if (err || !metadata || !metadata.format) resolve(15); 
            else resolve(parseFloat(metadata.format.duration));
        });
    });
}

function getClipDuration(filePath) {
    return new Promise((resolve) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err || !metadata || !metadata.format) resolve(3);
            else resolve(parseFloat(metadata.format.duration));
        });
    });
}

async function parseSrtFile(srtPath) {
    try {
        const content = await fs.readFile(srtPath, 'utf8');
        const blocks = content.replace(/\r/g, '').split('\n\n').filter(b => b.trim());
        const parsed = [];
        
        const timeToSec = (t) => {
            if (!t) return 0;
            const parts = t.split(':');
            if (parts.length !== 3) return 0;
            const [h, m, s_ms] = parts;
            const [s, ms] = s_ms.split(',');
            return (+h)*3600 + (+m)*60 + (+s) + (+ms)/1000;
        };

        for (const block of blocks) {
            const lines = block.split('\n');
            if (lines.length >= 3) {
                const timeLine = lines[1];
                const text = lines.slice(2).join(' ').trim();
                const [startStr, endStr] = timeLine.split(' --> ');
                
                parsed.push({
                    start: Number(timeToSec(startStr).toFixed(1)),
                    end: Number(timeToSec(endStr).toFixed(1)),
                    text: text
                });
            }
        }
        return parsed;
    } catch (err) {
        return [];
    }
}

async function buildTimeline(projectPath, scriptText, voicePath, srtPath, apiKey) {
    const sources = await getProjectSources(projectPath);
    const availableClips = [];
    
    for (const src of sources) {
        if (src.status === 'done') {
            const meta = await getMetadata(projectPath, src.fileName);
            const absPath = path.join(projectPath, '01_Source', src.fileName);
            const realDuration = await getClipDuration(absPath);
            
            availableClips.push({
                file: src.fileName,
                max_duration: Number(realDuration.toFixed(1)),
                main_content: meta.MainContent || meta.Description,
                purpose: meta.Purpose
            });
        }
    }

    if (availableClips.length === 0) {
        throw new Error("Dự án chưa có video nào được AI quét! Vui lòng quay lại Tab 1.");
    }

    const audioDuration = await getAudioDuration(voicePath);
    const audioDurRounded = Number(audioDuration.toFixed(1));
    const srtData = await parseSrtFile(srtPath);

    const prompt = `Bạn là Đạo diễn Video Cắt Cảnh (Video Editor) với phong cách TikTok/Shorts nghìn view.
    
    [TIMING VÀ NỘI DUNG TỪ FILE SRT]:
    ${JSON.stringify(srtData, null, 2)}
    
    [TỔNG THỜI LƯỢNG ĐÚNG BẰNG]: ${audioDurRounded} giây.
    
    [TÀI NGUYÊN VIDEO]:
    ${JSON.stringify(availableClips, null, 2)}
    
    THIẾT QUÂN LUẬT (VI PHẠM SẼ BỊ PHẠT NẶNG):
    1. CẮT CẢNH NHANH (CỰC KỲ QUAN TRỌNG): Mỗi video clip (tương ứng 1 biến "duration") BẮT BUỘC chỉ được dài từ 1.0 giây đến TỐI ĐA 2.5 giây. TUYỆT ĐỐI KHÔNG ĐỂ DURATION QUÁ 2.5 GIÂY!
    2. CHIA NHỎ SRT: File SRT là mốc thời gian để bạn hiểu "lúc đó đang nói cái gì". Nếu 1 câu SRT dài 4 giây, BẠN PHẢI DÙNG 2 ĐẾN 3 VIDEO KHÁC NHAU ĐỂ GHÉP LẠI (Ví dụ: 2.0s + 2.0s = 4.0s). Tuyệt đối không lấy 1 video dài 4 giây.
    3. TOÁN HỌC: Tổng tất cả các "duration" cộng lại PHẢI ĐÚNG CHÍNH XÁC bằng ${audioDurRounded}.
    4. CẤM VƯỢT MAX_DURATION: Không gán "duration" lớn hơn "max_duration" của clip gốc.
    5. XỬ LÝ CHỐT SALE: Khi đến đoạn thoại cuối cùng kêu gọi mua hàng, hãy bốc những video có Nội dung là Toàn cảnh sản phẩm đã dọn dẹp sạch sẽ.
    6. CHỐNG TRÙNG LẶP: Không được lặp lại 1 video 2 lần liên tiếp.

    TRẢ VỀ DUY NHẤT MẢNG JSON TẠO TIMELINE (ĐỪNG VIẾT GÌ THÊM BÊN NGOÀI):
    {
      "timeline": [
         { "file": "Tên-file.mp4", "duration": 2.0 }
      ]
    }`;

    console.log(`[Matcher] Yêu cầu Kie.ai phân tích Xếp Timeline...`);
    const cleanKey = apiKey.trim();
    
    try {
        const payload = {
            model: "gpt-5-6-luna",
            input: [{ role: "user", content: [{ type: "input_text", text: prompt }] }],
            reasoning: { effort: "high" }
        };

        const response = await axios.post('https://api.kie.ai/codex/v1/responses', payload, {
            headers: { 'Authorization': `Bearer ${cleanKey}`, 'Content-Type': 'application/json' }
        });

        let resObj = extractKieResponse(response.data);
        if (!resObj.content) throw new Error("AI trả về rỗng.");

        // BỘ LỌC THÉP
        let cleanJSON = resObj.content.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/g, '').trim();
        const jsonMatch = cleanJSON.match(/\{[\s\S]*\}/);
        if (jsonMatch) cleanJSON = jsonMatch[0];
        
        const data = JSON.parse(cleanJSON);
        
        return { timeline: data.timeline, credits: resObj.credits, tokens: resObj.tokens };
    } catch (error) {
        let errMsg = error.message;
        if (error.response && error.response.data) {
            errMsg = typeof error.response.data === 'object' ? JSON.stringify(error.response.data) : error.response.data;
        }
        throw new Error("Lỗi thuật toán Timeline: " + errMsg);
    }
}

module.exports = { buildTimeline, getAudioDuration };