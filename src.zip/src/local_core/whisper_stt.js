// File path: src/local_core/whisper_stt.js
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');
const axios = require('axios');
const FormData = require('form-data'); // Thư viện xử lý upload file

async function extractAudioAndSTT(videoPath, apiKey) {
    if (!apiKey) throw new Error("Vui lòng nhập API Key để sử dụng Whisper AI bóc băng.");

    // Tạo file âm thanh tạm
    const tempAudioName = `temp_audio_${crypto.randomBytes(4).toString('hex')}.mp3`;
    const tempAudioPath = path.join(os.tmpdir(), tempAudioName);

    try {
        // 1. Dùng FFmpeg bóc tách riêng phần âm thanh (.mp3) khỏi video
        console.log(`[FFmpeg] Đang trích xuất audio từ: ${videoPath}`);
        await new Promise((resolve, reject) => {
            ffmpeg(videoPath)
                .noVideo() // Bỏ hình
                .audioCodec('libmp3lame') // Nén mp3
                .save(tempAudioPath)
                .on('end', resolve)
                .on('error', reject);
        });

        // 2. Gửi file mp3 vừa tách lên OpenAI Whisper API
        console.log(`[OpenAI Whisper] Đang gửi file lên AI bóc chữ...`);
        const formData = new FormData();
        formData.append('file', fs.createReadStream(tempAudioPath));
        formData.append('model', 'whisper-1');

        const response = await axios.post('https://api.openai.com/v1/audio/transcriptions', formData, {
            headers: {
                ...formData.getHeaders(),
                'Authorization': `Bearer ${apiKey}`
            }
        });

        const transcriptText = response.data.text;
        
        // 3. Xóa file âm thanh tạm đi cho nhẹ máy
        await fs.promises.unlink(tempAudioPath).catch(e => console.error("Lỗi xóa file tạm mp3:", e));
        
        return transcriptText;

    } catch (error) {
        // Có lỗi cũng phải dọn dẹp file rác
        await fs.promises.unlink(tempAudioPath).catch(() => {});
        throw new Error("Lỗi STT: " + (error.response?.data?.error?.message || error.message));
    }
}

module.exports = { extractAudioAndSTT };